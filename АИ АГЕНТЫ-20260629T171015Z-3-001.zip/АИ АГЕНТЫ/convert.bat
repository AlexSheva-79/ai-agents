@echo off
echo 🚀 Начинаю пакетную конвертацию 24 файлов...
echo.

for %%F in (*.mp4) do (
    echo 📹 Обрабатываю: %%F
    ffmpeg -y -i "%%F" ^
        -vf "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2:color=black" ^
        -c:v libx264 -preset medium -profile:v high -level 4.1 ^
        -r 60 -b:v 15M -maxrate 15M -bufsize 20M -g 120 ^
        -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart ^
        "%%~nF_ig.mp4"
    echo ✅ Готово: %%~nF_ig.mp4
    echo.
)
echo 🎉 Все файлы обработаны! Новые файлы имеют суффикс _ig.mp4
pause